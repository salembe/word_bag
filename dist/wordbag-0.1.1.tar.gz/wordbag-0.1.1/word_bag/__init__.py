import jieba
jieba.load_userdict('word.txt')
print '调用'